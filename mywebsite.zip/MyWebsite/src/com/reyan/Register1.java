package com.reyan;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class Register
 */
@WebServlet(name = "Register1", urlPatterns = { "/Register1" })
public class Register1 extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public Register1() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) 
			throws ServletException, IOException {
	
		response.setContentType("text/html");
		PrintWriter out = response.getWriter();
		String n=request.getParameter("Name");  
		String e=request.getParameter("email");  
		String m=request.getParameter("Notes"); 
		try{  
			Class.forName("oracle.jdbc.driver.OracleDriver");  
			Connection con=DriverManager.getConnection(  
			"jdbc:oracle:thin:@localhost:1521:xe","system","reyan123");  
			  
			PreparedStatement ps=con.prepareStatement(  
			"insert into MYWEBSITE values(?,?,?)");  
			  
			ps.setString(1,n);  
			ps.setString(2,e);  
			ps.setString(3,m); 
			int i=ps.executeUpdate();  
			 
    if(i>0){  
    	out.println("Thank you for our Time..."); 
            RequestDispatcher rd=request.getRequestDispatcher("demo.html");  
        rd.include(request, response);  }
   
    else { 
        out.print("Sorry try it again!!!");  
        RequestDispatcher rd=request.getRequestDispatcher("/index.html");  
        rd.include(request, response);  
    } }catch (Exception e2) {
    out.print(e2);	
    }
	}}
    
		
	
    
	
